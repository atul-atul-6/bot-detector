/**
 * injector.js
 * Runs on laksh-uat.ipsator.com after collector.js
 * Sets the API URL and session token, then starts monitoring
 */

(function () {
  "use strict";

  // ─────────────────────────────────────────────────────────────
  // CHANGE THIS to your Codespace public URL (port 8000)
  // Example: https://YOUR-CODESPACE-NAME-8000.preview.app.github.dev
  // ─────────────────────────────────────────────────────────────
  const API_URL = "https://YOUR-CODESPACE-NAME-8000.preview.app.github.dev";

  // Generate a unique session token for this browser session
  const SESSION_TOKEN =
    sessionStorage.getItem("bot_session_token") ||
    (() => {
      const t = "sess-" + Math.random().toString(36).slice(2, 12);
      sessionStorage.setItem("bot_session_token", t);
      return t;
    })();

  // Expose to collector.js
  window.BOT_DETECTOR_API   = API_URL;
  window.BOT_DETECTOR_TOKEN = SESSION_TOKEN;

  // ── Intercept checkout buttons ──────────────────────────────
  // Tries common checkout button selectors used by ticketing sites
  const CHECKOUT_SELECTORS = [
    "button[type=submit]",
    "input[type=submit]",
    "[class*='checkout']",
    "[class*='buy']",
    "[class*='purchase']",
    "[class*='book']",
    "[id*='checkout']",
    "[id*='buy-now']",
    "[data-action='checkout']",
  ];

  function attachCheckoutListeners() {
    CHECKOUT_SELECTORS.forEach((sel) => {
      document.querySelectorAll(sel).forEach((el) => {
        if (el.dataset.botDetectorAttached) return; // avoid double-attaching
        el.dataset.botDetectorAttached = "1";
        el.addEventListener("click", () => sendSignal("checkout"), { once: false });
      });
    });
  }

  // ── Ticket / seat selectors ─────────────────────────────────
  const TICKET_SELECTORS = [
    "[class*='ticket']",
    "[class*='seat']",
    "[class*='section']",
    "[class*='price']",
    "[data-ticket]",
    "[data-seat]",
  ];

  function attachTicketListeners() {
    TICKET_SELECTORS.forEach((sel) => {
      document.querySelectorAll(sel).forEach((el) => {
        if (el.dataset.botTicketAttached) return;
        el.dataset.botTicketAttached = "1";
        el.addEventListener("click", () => sendSignal("selection"));
      });
    });
  }

  // ── Signal sender ───────────────────────────────────────────
  function sendSignal(trigger) {
    const payload = {
      session_token: SESSION_TOKEN,
      trigger,
      // collector.js sets these on window when it runs
      time_to_select:       window._botDetector?.timeToSelect       || null,
      time_to_checkout:     window._botDetector?.timeToCheckout     || null,
      mouse_entropy:        window._botDetector?.mouseEntropy       || null,
      scroll_events:        window._botDetector?.scrollEvents       || null,
      hover_duration:       window._botDetector?.hoverDuration      || null,
      keystroke_regularity: window._botDetector?.keystrokeRegularity || null,
      selection_method:     window._botDetector?.selectionMethod    || null,
      mouse_path_length:    window._botDetector?.mousePathLength    || null,
    };

    fetch(API_URL + "/api/session/signal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      keepalive: true,
    })
      .then((r) => r.json())
      .then((data) => {
        console.log(
          `%c[Bot Detector] ${trigger.toUpperCase()} → score: ${data.score} | action: ${data.action} | ${data.reason}`,
          data.action === "block"
            ? "color:red;font-weight:bold"
            : data.action === "queue"
            ? "color:orange;font-weight:bold"
            : "color:green;font-weight:bold"
        );
        // Store last result for popup to read
        sessionStorage.setItem("bot_last_result", JSON.stringify(data));
        window.dispatchEvent(new CustomEvent("botDetectorResult", { detail: data }));
      })
      .catch((err) => {
        console.warn("[Bot Detector] API unreachable:", err.message);
        console.warn("[Bot Detector] Make sure port 8000 is PUBLIC in Codespace Ports tab");
      });
  }

  // ── Run on page load + watch for dynamic content (SPAs) ─────
  attachCheckoutListeners();
  attachTicketListeners();

  // Re-attach on DOM changes (for single-page apps like React/Vue)
  new MutationObserver(() => {
    attachCheckoutListeners();
    attachTicketListeners();
  }).observe(document.body, { childList: true, subtree: true });

  console.log(
    "%c[Bot Detector] Active on " + window.location.hostname,
    "color:#7F77DD;font-weight:bold"
  );
  console.log("[Bot Detector] API:", API_URL);
  console.log("[Bot Detector] Session:", SESSION_TOKEN);
})();
