/**
 * collector.js — Chrome Extension Version
 * Collects behavioral signals silently on the page.
 * Exposes results on window._botDetector for injector.js to read.
 */
(function () {
  "use strict";

  const t0 = Date.now();

  // Shared state exposed to injector.js
  window._botDetector = {
    timeToSelect:        null,
    timeToCheckout:      null,
    mouseEntropy:        0,
    mousePathLength:     0,
    scrollEvents:        0,
    hoverDuration:       0,
    keystrokeRegularity: 0,
    selectionMethod:     null,
  };

  const state = {
    mousePath:    [],
    hoverMap:     {},
    keyIntervals: [],
    lastKey:      0,
    selectionAt:  null,
    checkoutAt:   null,
  };

  // ── Mouse trajectory ────────────────────────────────────────
  let lastSample = 0;
  document.addEventListener("mousemove", (e) => {
    const now = Date.now();
    if (now - lastSample > 40) {
      state.mousePath.push([e.clientX, e.clientY, now - t0]);
      lastSample = now;
      window._botDetector.mousePathLength = state.mousePath.length;
      window._botDetector.mouseEntropy    = calcEntropy(state.mousePath);
    }
  });

  // ── Scroll ──────────────────────────────────────────────────
  document.addEventListener("scroll", () => {
    window._botDetector.scrollEvents++;
  }, { passive: true });

  // ── Hover tracking ──────────────────────────────────────────
  document.addEventListener("mouseover", (e) => {
    const el = e.target;
    if (isTicketElement(el)) {
      state.hoverMap[uniqueKey(el)] = Date.now();
    }
  });
  document.addEventListener("mouseout", (e) => {
    const el  = e.target;
    const key = uniqueKey(el);
    if (state.hoverMap[key] && typeof state.hoverMap[key] === "number") {
      state.hoverMap[key] = Date.now() - state.hoverMap[key];
      const total = Object.values(state.hoverMap)
        .filter((v) => v < 1e6)
        .reduce((a, b) => a + b, 0);
      window._botDetector.hoverDuration = +(total / 1000).toFixed(3);
    }
  });

  // ── Keystroke timing ────────────────────────────────────────
  document.addEventListener("keydown", () => {
    const now = Date.now();
    if (state.lastKey) state.keyIntervals.push(now - state.lastKey);
    state.lastKey = now;
    window._botDetector.keystrokeRegularity = calcKeystrokeReg(state.keyIntervals);
  });

  // ── Selection detection ─────────────────────────────────────
  document.addEventListener("click", (e) => {
    if (!state.selectionAt && isTicketElement(e.target)) {
      state.selectionAt = Date.now();
      window._botDetector.selectionMethod  = e.isTrusted ? "click" : "dom_inject";
      window._botDetector.timeToSelect     = +((state.selectionAt - t0) / 1000).toFixed(3);
    }
    if (isCheckoutElement(e.target)) {
      state.checkoutAt = Date.now();
      if (!window._botDetector.selectionMethod) {
        window._botDetector.selectionMethod = e.isTrusted ? "click" : "dom_inject";
      }
      if (state.selectionAt) {
        window._botDetector.timeToCheckout =
          +((state.checkoutAt - state.selectionAt) / 1000).toFixed(3);
      }
    }
  }, true);

  // ── Helpers ─────────────────────────────────────────────────
  function isTicketElement(el) {
    if (!el || !el.className) return false;
    const c = (el.className + " " + (el.id || "")).toLowerCase();
    return /ticket|seat|section|price|row|zone/.test(c) || el.dataset?.ticket;
  }

  function isCheckoutElement(el) {
    if (!el) return false;
    const c = (el.className + " " + (el.id || "") + " " + (el.textContent || "")).toLowerCase();
    return /checkout|buy|purchase|book|confirm|pay/.test(c) || el.type === "submit";
  }

  function uniqueKey(el) {
    return el.tagName + (el.id || el.className || "").slice(0, 20);
  }

  function calcEntropy(path) {
    if (path.length < 4) return 0;
    const angles = [];
    for (let i = 1; i < path.length - 1; i++) {
      const a1 = Math.atan2(path[i][1] - path[i-1][1], path[i][0] - path[i-1][0]);
      const a2 = Math.atan2(path[i+1][1] - path[i][1], path[i+1][0] - path[i][0]);
      angles.push(((a2 - a1 + Math.PI) / (2 * Math.PI)) * 8);
    }
    const bins = new Array(8).fill(0);
    angles.forEach((a) => bins[Math.floor(a) % 8]++);
    const n = angles.length;
    const h = -bins.reduce((acc, c) => {
      const p = c / n;
      return p > 0 ? acc + p * Math.log2(p) : acc;
    }, 0);
    return parseFloat((h / Math.log2(8)).toFixed(4));
  }

  function calcKeystrokeReg(intervals) {
    if (intervals.length < 3) return 0;
    const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    const std  = Math.sqrt(
      intervals.map((t) => (t - mean) ** 2).reduce((a, b) => a + b, 0) / intervals.length
    );
    return parseFloat(Math.max(0, Math.min(1, 1 - std / mean)).toFixed(4));
  }
})();
